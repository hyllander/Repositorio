package figuras;

public class Triangulo implements FiguraGeometrica2D {
    private double base;
    private double altura;

    public Triangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    @Override
    public double calcularArea() {
        return 0.5 * base * altura;
    }

    @Override
    public double calcularPerimetro() {
        // Implementar cálculo do perímetro se necessário
        return 0; // Valor fictício
    }

    @Override
    public String obterTipoFigura() {
        return "Triângulo";
    }
}
