package figuras;

public interface FiguraGeometrica2D extends Comparable<FiguraGeometrica2D> {
    double calcularArea();
    double calcularPerimetro();
    String obterTipoFigura();

    @Override
    default int compareTo(FiguraGeometrica2D outraFigura) {
        return Double.compare(this.calcularArea(), outraFigura.calcularArea());
    }
}
