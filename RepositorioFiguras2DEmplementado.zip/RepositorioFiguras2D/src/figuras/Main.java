package figuras;

public class Main {
    public static void main(String[] args) {
        RepositorioDeFiguras2D repositorio = new RepositorioDeFiguras2D();

        FiguraGeometrica2D circulo = new Circulo(5);
        FiguraGeometrica2D quadrado = new Quadrado(4);
        FiguraGeometrica2D triangulo = new Triangulo(6, 8); // Suponha que Triangulo é outra figura implementada

        repositorio.adicionarFigura(circulo);
        repositorio.adicionarFigura(quadrado);
        repositorio.adicionarFigura(triangulo);

        // Ordenar figuras por área
        repositorio.ordenarFigurasPorArea();

        // Exibir informações após ordenação
        for (int i = 0; i < 3; i++) {
            System.out.println("Tipo da figura na posição " + i + ": " + repositorio.recuperarTipoFigura(i));
            System.out.println("Área da figura: " + repositorio.recuperarArea(i));
            System.out.println("Perímetro da figura: " + repositorio.recuperarPerimetro(i));
        }
    }
}
