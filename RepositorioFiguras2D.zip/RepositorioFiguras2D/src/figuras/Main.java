package figuras;

public class Main {
    public static void main(String[] args) {
        RepositorioDeFiguras2D repositorio = new RepositorioDeFiguras2D();

        FiguraGeometrica2D circulo = new Circulo(5);
        FiguraGeometrica2D quadrado = new Quadrado(4);

        repositorio.adicionarFigura(circulo);
        repositorio.adicionarFigura(quadrado);

        System.out.println("Área do círculo: " + repositorio.recuperarArea(0));
        System.out.println("Perímetro do círculo: " + repositorio.recuperarPerimetro(0));
        System.out.println("Tipo da figura na posição 0: " + repositorio.recuperarTipoFigura(0));

        System.out.println("Área do quadrado: " + repositorio.recuperarArea(1));
        System.out.println("Perímetro do quadrado: " + repositorio.recuperarPerimetro(1));
        System.out.println("Tipo da figura na posição 1: " + repositorio.recuperarTipoFigura(1));

        repositorio.removerFigura(0);
        System.out.println("Após remover, tipo da figura na posição 0: " + repositorio.recuperarTipoFigura(0));
    }
}
