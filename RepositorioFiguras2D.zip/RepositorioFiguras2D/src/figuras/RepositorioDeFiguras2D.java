package figuras;

import java.util.ArrayList;
import java.util.List;

public class RepositorioDeFiguras2D {
    private List<FiguraGeometrica2D> figuras;

    public RepositorioDeFiguras2D() {
        this.figuras = new ArrayList<>();
    }

    public void adicionarFigura(FiguraGeometrica2D figura) {
        figuras.add(figura);
    }

    public void removerFigura(int posicao) {
        if (posicao >= 0 && posicao < figuras.size()) {
            figuras.remove(posicao);
        } else {
            throw new IndexOutOfBoundsException("Posição inválida.");
        }
    }

    public double recuperarArea(int posicao) {
        if (posicao >= 0 && posicao < figuras.size()) {
            return figuras.get(posicao).calcularArea();
        } else {
            throw new IndexOutOfBoundsException("Posição inválida.");
        }
    }

    public double recuperarPerimetro(int posicao) {
        if (posicao >= 0 && posicao < figuras.size()) {
            return figuras.get(posicao).calcularPerimetro();
        } else {
            throw new IndexOutOfBoundsException("Posição inválida.");
        }
    }

    public String recuperarTipoFigura(int posicao) {
        if (posicao >= 0 && posicao < figuras.size()) {
            return figuras.get(posicao).obterTipoFigura();
        } else {
            throw new IndexOutOfBoundsException("Posição inválida.");
        }
    }
}
