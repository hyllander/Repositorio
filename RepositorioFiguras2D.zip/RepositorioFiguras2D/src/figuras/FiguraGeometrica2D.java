package figuras;

public interface FiguraGeometrica2D {
    double calcularArea();
    double calcularPerimetro();
    String obterTipoFigura();
}
